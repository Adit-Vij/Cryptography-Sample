from keyGen import AESKeyGen
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
import os


class Encryptor:
    def __init__(self):
        self.aes_key = None
        self.cipher_text = None
        self.cipher_key = None
        self.enc_file = None

    def pad(self, data):
        pad_len = 16 - (len(data) % 16)
        return data + bytes([pad_len] * pad_len)

    def encrypt_file(self, file_path):
        kg = AESKeyGen()
        self.aes_key = kg.generate_key()
        iv = os.urandom(16)
        cipher = Cipher(algorithms.AES(self.aes_key), modes.CBC(iv), backend=default_backend())
        encryptor = cipher.encryptor()

        with open(file_path, 'rb') as f:
            plain_text = f.read()

        # Apply padding
        padded_plain_text = self.pad(plain_text)

        # Encrypt the file
        self.cipher_text = iv + encryptor.update(padded_plain_text) + encryptor.finalize()

    def encrypt_aes_key(self, source_private_key_path, destination_public_key_path):
            with open(source_private_key_path, 'rb') as pem_in:
                source_private_key = serialization.load_pem_private_key(pem_in.read(), password=None)

            with open(destination_public_key_path, 'rb') as pem_in:
                destination_public_key = serialization.load_pem_public_key(pem_in.read())

            # Sign the AES key with the source's private key
            signed_aes_key = source_private_key.sign(
                self.aes_key,  # Use self.aes_key instead of aes_key
                padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH
                ),
                hashes.SHA256()
            )

            # Encrypt the signed AES key with the destination's public key
            encrypted_aes_key = destination_public_key.encrypt(
                signed_aes_key,
                padding.OAEP(
                    mgf=padding.MGF1(algorithm=hashes.SHA256()),
                    algorithm=hashes.SHA256(),
                    label=None
                )
            )
            self.cipher_key = encrypted_aes_key

    '''except (OSError, IOError) as e:
            print(f"Failed to encrypt the AES key: {e}")
        except Exception as e:
            print(f"An error occurred: {e}")'''

    def write_encrypted_file(self, encrypted_file_path):
        try:
            with open(encrypted_file_path, 'wb') as f_out:
                f_out.write(len(self.cipher_key).to_bytes(4, byteorder='big'))
                f_out.write(self.cipher_key)
                f_out.write(self.cipher_text)

            print(f"Encrypted file successfully written to: {encrypted_file_path}")

        except (OSError, IOError) as e:
            print(f"Failed to write the encrypted file: {e}")
        except Exception as e:
            print(f"An error occurred: {e}")
