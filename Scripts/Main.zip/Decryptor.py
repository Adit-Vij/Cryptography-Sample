from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import serialization, padding as sym_padding
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend

class Decryptor:
    def __init__(self):
        self.decrypted_aes_key = None
        self.plain_text = None

    def decrypt_aes_key(self, encrypted_key, source_public_key_path, destination_private_key_path):
        try:
            # Load the source's RSA public key
            with open(source_public_key_path, 'rb') as pem_in:
                source_public_key = serialization.load_pem_public_key(pem_in.read())

            # Load the destination's RSA private key
            with open(destination_private_key_path, 'rb') as pem_in:
                destination_private_key = serialization.load_pem_private_key(pem_in.read(), password=None)

            # Decrypt the encrypted AES key with the destination's private key
            signed_aes_key = destination_private_key.decrypt(
                encrypted_key,
                padding.OAEP(
                    mgf=padding.MGF1(algorithm=hashes.SHA256()),
                    algorithm=hashes.SHA256(),
                    label=None
                )
            )

            # Verify the AES key signature using the source's public key
            aes_key = source_public_key.verify(
                signed_aes_key,
                aes_key,
                padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH
                ),
                hashes.SHA256()
            )

            self.decrypted_aes_key = aes_key

        except Exception as e:
            print(f"Failed to decrypt the AES key: {e}")

    def decrypt_file(self, encrypted_file_path):
        try:
            with open(encrypted_file_path, 'rb') as f_in:
                # Read the length of the encrypted AES key (first 4 bytes)
                key_len = int.from_bytes(f_in.read(4), byteorder='big')

                # Extract the encrypted AES key
                encrypted_aes_key = f_in.read(key_len)

                # Extract the IV (next 16 bytes)
                iv = f_in.read(16)

                # Extract the ciphertext (remaining data)
                ciphertext = f_in.read()

            # Decrypt the AES key
            self.decrypt_aes_key(encrypted_aes_key)

            # Initialize the AES cipher for decryption
            cipher = Cipher(algorithms.AES(self.decrypted_aes_key), modes.CBC(iv), backend=default_backend())
            decryptor = cipher.decryptor()

            # Decrypt the ciphertext
            decrypted_data = decryptor.update(ciphertext) + decryptor.finalize()

            # Unpad the decrypted data
            unpadder = sym_padding.PKCS7(algorithms.AES.block_size).unpadder()
            self.plain_text = unpadder.update(decrypted_data) + unpadder.finalize()

            print("File successfully decrypted")

        except Exception as e:
            print(f"Failed to decrypt the file: {e}")

    def save_plain_text(self, output_file_path):
        try:
            with open(output_file_path, 'wb') as f_out:
                f_out.write(self.plain_text)

            print(f"Plain text successfully saved to: {output_file_path}")

        except (OSError, IOError) as e:
            print(f"Failed to save the plain text: {e}")
        except Exception as e:
            print(f"An error occurred: {e}")